from . import models

from rest_framework import serializers


class CertificationValiditySerializer(serializers.ModelSerializer):

    class Meta:
        model = models.CertificationValidity
        fields = (
            'pk', 
            'valid_for_purpose', 
            'farm_purpose', 
            'created', 
            'last_updated', 
            'issue_date', 
            'start_date', 
            'expiry_date', 
        )


