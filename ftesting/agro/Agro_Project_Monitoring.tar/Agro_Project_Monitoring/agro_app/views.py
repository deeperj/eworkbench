from django.views.generic import DetailView, ListView, UpdateView, CreateView
from .models import CertificationValidity
from .forms import CertificationValidityForm


class CertificationValidityListView(ListView):
    model = CertificationValidity


class CertificationValidityCreateView(CreateView):
    model = CertificationValidity
    form_class = CertificationValidityForm


class CertificationValidityDetailView(DetailView):
    model = CertificationValidity


class CertificationValidityUpdateView(UpdateView):
    model = CertificationValidity
    form_class = CertificationValidityForm

