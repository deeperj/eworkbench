from django.contrib import admin
from django import forms
from .models import CertificationValidity

class CertificationValidityAdminForm(forms.ModelForm):

    class Meta:
        model = CertificationValidity
        fields = '__all__'


class CertificationValidityAdmin(admin.ModelAdmin):
    form = CertificationValidityAdminForm
    list_display = ['valid_for_purpose', 'farm_purpose', 'created', 'last_updated', 'issue_date', 'start_date', 'expiry_date']
    readonly_fields = ['valid_for_purpose', 'farm_purpose', 'created', 'last_updated', 'issue_date', 'start_date', 'expiry_date']

admin.site.register(CertificationValidity, CertificationValidityAdmin)


