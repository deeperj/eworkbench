from django import forms
from .models import CertificationValidity


class CertificationValidityForm(forms.ModelForm):
    class Meta:
        model = CertificationValidity
        fields = ['valid_for_purpose', 'farm_purpose', 'issue_date', 'start_date', 'expiry_date']


