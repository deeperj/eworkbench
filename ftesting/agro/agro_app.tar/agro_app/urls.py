from django.urls import path, include
from rest_framework import routers

from . import api
from . import views

router = routers.DefaultRouter()
router.register(r'certificationvalidity', api.CertificationValidityViewSet)


urlpatterns = (
    # urls for Django Rest Framework API
    path('api/v1/', include(router.urls)),
)

urlpatterns += (
    # urls for CertificationValidity
    path('agro_app/certificationvalidity/', views.CertificationValidityListView.as_view(), name='agro_app_certificationvalidity_list'),
    path('agro_app/certificationvalidity/create/', views.CertificationValidityCreateView.as_view(), name='agro_app_certificationvalidity_create'),
    path('agro_app/certificationvalidity/detail/<int:pk>/', views.CertificationValidityDetailView.as_view(), name='agro_app_certificationvalidity_detail'),
    path('agro_app/certificationvalidity/update/<int:pk>/', views.CertificationValidityUpdateView.as_view(), name='agro_app_certificationvalidity_update'),
)

