from . import models
from . import serializers
from rest_framework import viewsets, permissions


class CertificationValidityViewSet(viewsets.ModelViewSet):
    """ViewSet for the CertificationValidity class"""

    queryset = models.CertificationValidity.objects.all()
    serializer_class = serializers.CertificationValiditySerializer
    permission_classes = [permissions.IsAuthenticated]


